# Déploiement Netlify - MaterialVision

## Méthode recommandée
1. Pousser ce projet sur GitHub.
2. Netlify > Add new project > Import from Git.
3. Sélectionner le dépôt MaterialVision.
4. Build command: npm run build:web
5. Publish directory: dist
6. Deploy.

## Variables utiles
EXPO_PUBLIC_BLINK_PROJECT_ID
EXPO_PUBLIC_BLINK_PUBLISHABLE_KEY

Le fichier netlify.toml configure déjà le build et les redirections.
