module.exports = function (api) {
  api.cache(true);
  return {
    presets: [
      [
        'babel-preset-expo',
        {
          // Required by Blink SDK and Expo web builds that use import.meta.
          unstable_transformImportMeta: true,
        },
      ],
    ],
    plugins: [
      // Must be listed last for Reanimated/Worklets.
      'react-native-worklets/plugin',
    ],
  };
};
