# Déploiement Vercel

Réglages à utiliser dans Vercel :

- Install Command: `npm install --include=dev`
- Build Command: `npm run build:web`
- Output Directory: `dist`

La dépendance `babel-preset-expo` est maintenant dans `dependencies` pour éviter l’erreur Vercel `Cannot find module babel-preset-expo`.
