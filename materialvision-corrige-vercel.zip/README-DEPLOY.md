# Déploiement Vercel

Réglages Vercel recommandés :

- Install Command: `npm install`
- Build Command: `npm run build:web`
- Output Directory: `dist`

Le fichier `vercel.json` contient déjà ces réglages. Après avoir envoyé ce projet sur GitHub, importe le dépôt sur Vercel puis clique sur Deploy.

Variables d'environnement optionnelles :

- `EXPO_PUBLIC_BLINK_PROJECT_ID`
- `EXPO_PUBLIC_BLINK_PUBLISHABLE_KEY`

Si tu ne les ajoutes pas, le projet utilise les valeurs par défaut présentes dans `lib/blink.ts`.
